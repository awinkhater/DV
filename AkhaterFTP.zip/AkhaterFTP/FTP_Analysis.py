import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
#SKlearn
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

#Clean Dataset
df= pd.read_csv('FTPDataset.csv')

#print(df.columns)
#Separating out the useful features for modeling
features = ['LotArea', 'BldgArea', 'NumBldgs',
                 'NumFloors', 'UnitsRes', 'UnitsTotal',
                 'LotFront', 'LotDepth', 'BldgFront',
                 'BldgDepth','LotType', 'BsmtCode', 'AssessLand', 'AssessTot']


dfF=df.loc[:, features]
dfF=pd.DataFrame(dfF)


#SUB SAMPLES FOR EASE OF PROCESSING
DF= df.sample(1200, random_state=1)
DF600= df.sample(600, random_state=1)
DF200= df.sample(200, random_state=1)
#Line Plot:
#For ease of processing we are using a subsample

sns.set_style('darkgrid')
sns.lineplot(data=DF, x="AssessTot", y="LotArea")
plt.title('Area to Value Lineplot')
plt.show()


#Distribution Analysis: stacked barplot

sns.set_style('darkgrid')
sns.histplot(data=df, x='AssessTot', hue='Borough',multiple="stack")
plt.title('Lot Value Histogram')
plt.show()

#Distribution Analysis: Grouped Barplot
sns.set_style('darkgrid')
sns.histplot(data=df, x='AssessTot', hue='Borough',multiple="dodge")
plt.title('Lot Value Histogram')
plt.show()

#==============Count plot

sns.set_style('darkgrid')
sns.countplot(data=df, x="SchoolDist", hue="Borough")
plt.xticks(rotation=45)
plt.title('School District Countplot')
plt.show()

# #================Cat Plot/ Violin Plot
# #
sns.catplot(data=DF, x="NumFloors", y="Borough", kind="violin", color=".9", inner=None)
sns.swarmplot(data=DF, x="NumFloors", y="Borough", size=0.1)
plt.title('Building Height by Borough CatPlot')
plt.show()

#================ Pie Chart
def pc1():
    B2=df.groupby('Borough').size()
    myexplode = [0.02, 0.02, 0.02, 0.02, 0.02]
    def absolute_value(val):
        a  = round(val/100.*B2.sum())
        return a
    plt.pie(B2, labels=['BK', 'BX','MN','QN','SI'], autopct=absolute_value, explode=myexplode)
    plt.title("Pie Chart of Borough Representation")
    plt.legend(bbox_to_anchor=(1.02, 0.1), loc='upper left', borderaxespad=0)
    plt.show()
pc1()
#=================== Displot
sns.set_style('darkgrid')
sns.displot(df, x="AssessTot", y="BldgArea", hue='Borough')
plt.title('Value vs Building Area Displot')
plt.tight_layout()
plt.show()
#=========================KDE/ Histplot
sns.displot(data=df, x="LotArea", hue='Borough', kind='kde', multiple='stack')
plt.title('Lot Area KDE Plot')
plt.tight_layout()
plt.show()
# #==================== PairPlot
ppfeatures = [ 'BldgArea','NumFloors', 'UnitsTotal', 'BsmtCode', 'AssessTot']
dpp=df.loc[:, ppfeatures]
dpp=pd.DataFrame(dpp)

sns.pairplot(dpp)
plt.title('Buidling Information Pairplot')
plt.show()
#===================== Heat Map
sns.heatmap(dfF.corr())
plt.title('Numerical Feature Heatmap')
plt.show()
#================= QQ USING DASH APP
# #================Sklearn Regression
X = np.array(df['LotArea']).reshape(-1, 1)
y = np.array(df['AssessTot']).reshape(-1, 1)


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

# Splitting the data into training and testing data
regr = LinearRegression()

regr.fit(X_train, y_train)
print(regr.score(X_test, y_test))
#Plotting it Here
y_pred = regr.predict(X_test)
plt.scatter(X_test, y_test, color='b')
plt.title('Lot Area to Value Regression Plot')
plt.xlabel('Lot Area')
plt.ylabel('Total Value $USD')
plt.plot(X_test, y_pred, color='r')

plt.show()
#=============== Box Plot Subplot
plt.figure(figsize=(20,20))
sns.set_style('darkgrid')
plt.subplot(2, 2, 1)
sns.boxplot(data=df, x="NumBldgs", y="AssessTot", hue="Borough")
plt.xticks(rotation=45)
plt.title('Number of Buildings to Value Plot')
plt.subplot(2, 2, 2)
sns.boxplot(data=df, x="PolicePrct", y="AssessTot")
plt.xticks(rotation=45)
plt.title('Building to Value Plot')
plt.subplot(2, 2, 3)
sns.boxplot(data=df, x="BsmtCode", y="AssessTot", hue="Borough")
plt.title('Basement Code to Value Plot')
plt.xticks(rotation=45)
plt.subplot(2, 2, 4)
sns.boxplot(data=df, x="NumFloors", y="AssessTot", hue="Borough")
plt.title('Number of Floors to Value Plot')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#ANOVA
import scipy.stats as stats
#
dfQN = df[df['Borough'] == 'QN']
dfMN = df[df['Borough'] == 'MN']
dfBK = df[df['Borough'] == 'BK']
dfBX = df[df['Borough'] == 'BX']
dfSI = df[df['Borough'] == 'SI']


# # stats f_oneway functions takes the groups as input and returns ANOVA F and p value
fvalue, pvalue = stats.f_oneway(dfQN['AssessTot'], dfMN['AssessTot'],
dfBK['AssessTot'],dfBX['AssessTot'],dfSI['AssessTot'])
print(fvalue, pvalue)


