import pandas as pd
import numpy as np
import plotly.express as px
from sklearn import preprocessing
from sklearn.decomposition import PCA
import scipy.stats
from plotly.subplots import make_subplots
from scipy import stats
import statsmodels
# Imports
import scipy
#Dash
import dash as dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output
import plotly.graph_objects as go
import plotly.figure_factory as ff

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
my_app= dash.Dash('My app', external_stylesheets = external_stylesheets)

# 0.22.0

#PreProcessing items
# # PART 1.1 Initial Dataset merge
# csv_files=['BK.csv','BX.csv','MN.csv','QN.csv','SI.csv']
# l = []
# for f in csv_files:
#     l.append(pd.read_csv(f))
# # #
# df_raw = pd.concat(l, ignore_index=True)
# df_raw
# #
# # print(len(df_raw))
# # df_raw.to_csv('NY_PLUTO.csv')
# #
# # PART 1.2 Initial Dataset read
#
df_raw=pd.read_csv('NY_PLUTO.csv')
df_raw.set_index(df_raw.columns[0])
# #TAKING ONLY THE MOST USEFUL COLUMNS
df_raw= df_raw[['Borough', 'Lot', 'SchoolDist',
                'Council','ZipCode','FireComp',
                'PolicePrct','HealthArea','SanitBoro',
                'Address', 'BldgClass',
                'LotArea', 'BldgArea', 'NumBldgs',
                'NumFloors', 'UnitsRes', 'UnitsTotal',
                'LotFront', 'LotDepth', 'BldgFront',
                'BldgDepth', 'LotType', 'BsmtCode', 'AssessLand', 'AssessTot']]

def remove_outliers(df, columns):
    for col in columns:

        Q3 = df[col].quantile(.75)
        Q1 = df[col].quantile(.25)
        IQR= Q3-Q1
        df = df[(df[col] <= Q3+(1.5 * IQR))]
        df = df[(df[col] >= Q1 - (1.5 * IQR))]
    return (df)

predf=df_raw.dropna()




#================== Final Dataset Prep
# predf=remove_outliers(predf, ['LotArea', 'BldgArea', 'NumBldgs',
# #                 'NumFloors', 'UnitsRes', 'UnitsTotal',
# #                 'LotFront', 'LotDepth', 'BldgFront',
# #                 'BldgDepth','BsmtCode', 'AssessLand', 'AssessTot'])
# predf = predf.sample(n=60000, random_state=10)
#
# # # #SAVING THE CLEAN DATASET
# predf.to_csv('FTPDataset.csv')


#Clean Dataset
df= pd.read_csv('FTPDataset.csv')

#print(df.columns)
#Separating out the useful features for modeling
features = ['LotArea', 'BldgArea', 'NumBldgs',
                 'NumFloors', 'UnitsRes', 'UnitsTotal',
                 'LotFront', 'LotDepth', 'BldgFront',
                 'BldgDepth','LotType', 'BsmtCode', 'AssessLand', 'AssessTot']


dfF=df.loc[:, features]
dfF=pd.DataFrame(dfF)
#FOR PCA
x=dfF.values
y = df.loc[:,['Borough']].values
scaler = preprocessing.StandardScaler().fit(x)
X_scaled = scaler.transform(x)

pca=PCA(n_components='mle', svd_solver='full')
pca.fit(X_scaled)

pcx = pca.fit_transform(X_scaled)
df_pca = pd.DataFrame(data = pcx)

#Pre Stats:
dfQN = df[df['Borough'] == 'QN']
dfMN = df[df['Borough'] == 'MN']
dfBK = df[df['Borough'] == 'BK']
dfBX = df[df['Borough'] == 'BX']
dfSI = df[df['Borough'] == 'SI']

print("QN", dfQN['AssessTot'].mean())
print("MN", dfMN['AssessTot'].mean())
print("BK", dfBK['AssessTot'].mean())
print("BX", dfBX['AssessTot'].mean())
print("SI", dfSI['AssessTot'].mean())




#============================================================APP
my_app = dash.Dash('Final Term Project App', external_stylesheets=external_stylesheets)
my_app.layout = html.Div([html.H1('Final Term Project'),
                            html.Br(),
                            dcc.Tabs(id='hw-questions',
                                   children=[
                                        dcc.Tab(label='Fig 0.1', value='f01'),
                                        dcc.Tab(label='Fig 0.2', value='f02'),
                                       dcc.Tab(label='Fig 1.1', value='f11'),
                                       dcc.Tab(label='Fig 1.2', value='f12'),
                                       dcc.Tab(label='Fig 1.3', value='f13'),
                                       dcc.Tab(label='Fig 1.4', value='f14'),
                                       dcc.Tab(label='Fig 1.5', value='f15'),
                                       dcc.Tab(label='Fig 1.6', value='f16'),
                                       dcc.Tab(label='Fig 1.7', value='f17'),
                                       dcc.Tab(label='Fig 1.8', value='f18'),
                                       dcc.Tab(label='Fig 1.9', value='f19'),
                                       dcc.Tab(label='Fig 1.10', value='f110'),
                                       dcc.Tab(label='Fig 1.11', value='f111'),
                                       dcc.Tab(label='Fig 1.12', value='f112')
                                   ]),
                            html.Div(id='layout')])
#fig 0.1
fig0_1_layout = html.Div(
    [
        html.P('Null Counts'),
        dcc.Dropdown(id='my-drop01', options=[
                     {'label': 'LotArea', 'value': 'LotArea'},
                     {'label': 'BldgArea', 'value': 'BldgArea '},
                     {'label': 'NumBldgs', 'value': 'NumBldgs'},
                     {'label': 'NumFloors', 'value': 'NumFloors'},
                    {'label': 'UnitsRes', 'value': 'UnitsRes'},
                     {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
                     {'label': 'LotFront', 'value': 'LotFront'},
                     {'label': 'LotDepth', 'value': 'LotDepth'},
                    {'label': 'BldgFront', 'value': 'BldgFront'},
                     {'label': 'BldgDepth', 'value': 'BldgDepth'},
                    {'label': 'Borough', 'value': 'Borough'},
                    {'label': 'Lot', 'value': 'Lot'},
                    {'label': 'SchoolDist', 'value': 'SchoolDist'},
                    {'label': 'Council', 'value': 'Council'},
                    {'label': 'ZipCode', 'value': 'ZipCode'},
                    {'label': 'FireComp', 'value': 'FireComp'},
                    {'label': 'PolicePrct', 'value': 'PolicePrct'},
                    {'label': 'Health Area', 'value': 'HealthArea'},
                    {'label': 'SanitBoro', 'value': 'SanitBoro'},
                    {'label': 'Address', 'value': 'Address'},
                    {'label': 'BldgClass', 'value': 'BldgClass'},
                      {'label': 'BsmtCode', 'value': 'BsmtCode'},
                     {'label': 'AssessLand', 'value': 'AssessLand'},
                   {'label': 'AssessTot', 'value': 'AssessTot'},
                 ], value= 20,
                     clearable= True), html.Div(id='my-out01') ])
#
#
@my_app.callback(
            Output(component_id='my-out01', component_property='children'),
            [Input(component_id='my-drop01', component_property='value')])

def update_nulls(B):
    N=df_raw[B].isna().sum()
    return (f"There are {N} Null Values in the {B} column of the raw dataset")
#=================================Fig 0.2
fig0_2_layout = html.Div(
    [
        dcc.Graph(id= 'my-graph021'),
        html.P('Outlier Distribution'),
        dcc.Dropdown(id='my-drop021', options=[
                     {'label': 'LotArea', 'value': 'LotArea'},
                     {'label': 'BldgArea', 'value': 'BldgArea'},
                     {'label': 'NumBldgs', 'value': 'NumBldgs'},
                     {'label': 'NumFloors', 'value': 'NumFloors'},
                    {'label': 'UnitsRes', 'value': 'UnitsRes'},
                     {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
                     {'label': 'LotFront', 'value': 'LotFront'},
                     {'label': 'LotDepth', 'value': 'LotDepth'},
                    {'label': 'BldgFront', 'value': 'BldgFront'},
                     {'label': 'BldgDepth', 'value': 'BldgDepth'},
                      {'label': 'BsmtCode', 'value': 'BsmtCode'},
                     {'label': 'AssessLand', 'value': 'AssessLand'},
                   {'label': 'AssessTot', 'value': 'AssessTot'},

                 ], value= 20,
                     clearable= True)])
#
#
@my_app.callback(
            Output(component_id='my-graph021', component_property='figure'),
            [Input(component_id='my-drop021', component_property='value')])

def update_outliers(B):
    fig1 = px.scatter(data_frame=predf, y=B, x=predf.index)
    x = np.linspace(0, len(predf), len(predf))
    IQR = predf[B].quantile(.75) - predf[B].quantile(.25)
    Y = predf[B].quantile(.75) + (1.5 * IQR)
    y = [Y] * len(x)
    fig2 = px.line(y=y, x=x)
    fig2.update_traces(line_color='#FF5733', line_width=2)

    Z = predf[B].quantile(.25) - (1.5 * IQR)
    z = [Z] * len(x)
    fig3 = px.line(y=z, x=x)
    fig3.update_traces(line_color='#FFA500', line_width=2)

    fig4 = go.Figure(data=fig1.data + fig2.data + fig3.data)
    fig4.update_layout(
        title="Variable IQR Visualizer: Red and Orange Lines are IQR Bounds",
        xaxis_title="Index Values",
        yaxis_title=f"Column Values: {B}",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        )
    )
    return(fig4)

#=================================== fig 1.1
#============ NORMALITY CHECKS FOR EACH VARIABLE

fig1_1_layout = html.Div(
    [

        html.P('Normalization Column'),
        dcc.Dropdown(id='my-drop11', options=[
                     {'label': 'LotArea', 'value': 'LotArea'},
                     {'label': 'BldgArea', 'value': 'BldgArea'},
                     {'label': 'NumBldgs', 'value': 'NumBldgs'},
                     {'label': 'NumFloors', 'value': 'NumFloors'},
                    {'label': 'UnitsRes', 'value': 'UnitsRes'},
                     {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
                     {'label': 'LotFront', 'value': 'LotFront'},
                     {'label': 'LotDepth', 'value': 'LotDepth'},
                    {'label': 'BldgFront', 'value': 'BldgFront'},
                     {'label': 'BldgDepth', 'value': 'BldgDepth'},
                      {'label': 'BsmtCode', 'value': 'BsmtCode'},
                     {'label': 'AssessLand', 'value': 'AssessLand'},
                   {'label': 'AssessTot', 'value': 'AssessTot'},

                 ], clearable= True),
        html.Br(),
        dcc.Graph(id= 'my-graph11'),
        html.Br(),
        html.Div([
                   dcc.Graph(id='my-graph12'),
                   html.Br(),
        html.Br(),
        html.Div(id='my-out11'),
            html.Br()

        ])
])

@my_app.callback(
            Output(component_id='my-graph11', component_property='figure'),
            [Input(component_id='my-drop11', component_property='value')])

def update_Norm(B):
    fig1 = px.histogram(df, x=B, template='plotly_white',)
    fig1.update_layout(
        title="Normality Graph",
        xaxis_title=f"Column Values: {B}",
        yaxis_title="Frequency",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        )
    )
    return(fig1)

@my_app.callback(
            Output(component_id='my-graph12', component_property='figure'),
            [Input(component_id='my-drop11', component_property='value')])

def update_QQ(a1):
    qq = stats.probplot(df[a1], dist='lognorm', sparams=(1))
    x = np.array([qq[0][0][0], qq[0][0][-1]])

    fig = go.Figure()
    fig.add_scatter(x=qq[0][0], y=qq[0][1], mode='markers')
    fig.add_scatter(x=x, y=qq[1][1] + qq[1][0] * x, mode='lines')
    fig.update_layout(
        title="QQ Plot",
        xaxis_title="Theoretical Quantities",
        yaxis_title="Standard Residuals",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        )
    )
    fig.layout.update(showlegend=False)
    return(fig)

@my_app.callback(
            Output(component_id='my-out11', component_property='children'),
            Input(component_id='my-drop11', component_property='value'))
def update_test(C):
    k, p = stats.normaltest(df[C])
    if p <= 0.05:
        return("Per the D'Agostino test, this column is not normally distributed")
    else:
        return ("Per the D'Agostino test, this column is normally distributed")

# #========================= Fig1.2

fig1_2_layout = html.Div(

    [
        dcc.Graph(id= 'my-graph21'),
        html.P('Number of Principal Components'),
        dcc.Slider(id='pca-slider21', min=1, max=10, value=1,
                   marks={1: 1,2:2,4: 4,6:6, 8:8, 10:10})
        ])


@my_app.callback(
            Output(component_id='my-graph21', component_property='figure'),
            [Input(component_id='pca-slider21', component_property='value')])

def update_pca(B):
    pca = PCA(n_components=B, svd_solver='full')
    pca.fit(X_scaled)
    fig1_2_1=px.line(np.cumsum(pca.explained_variance_ratio_) * 100)
    fig1_2_1.update_layout(
        title="Explained Variance Plot",
        xaxis_title="Principle Components",
        yaxis_title="Explained Variance",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        ))
    return(fig1_2_1)

#==================Fig 1.3
fig1_3_layout=html.Div(
[   html.H1('Heatmap and Correlation Matrix'),
        html.P('Desired Columns For Heatmap and Correlation'),
        dcc.Checklist(id='mycheck31', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea'},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},
        ]),

    html.Div([dcc.Graph(id='mygraph31')
    ])

])
@my_app.callback(
            Output(component_id='mygraph31', component_property='figure'),
            [Input(component_id='mycheck31', component_property='value')])

def update_Stats(a1):
    DFtemp = []
    DFtemp = pd.DataFrame(DFtemp)
    DFtemp[a1] = df[a1]
    corr = DFtemp.corr()
    fig = go.Figure(data=go.Heatmap(z=corr.values,
                                    x=DFtemp.columns,
                                    y=DFtemp.columns))
    fig.update_layout(
        title="Heatmap",
        xaxis_title="Correlation Coeffecients",

        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        ))
    return fig


#=================Fig1.4
fig1_4_layout= html.Div(
[html.H1('Basic Statistics of Each Column of the Dataset'),
        html.P('Desired Column'),
        dcc.Dropdown(id='my-drop41', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea '},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'Borough', 'value': 'Borough'},
            {'label': 'Lot', 'value': 'Lot'},
            {'label': 'SchoolDist', 'value': 'SchoolDist'},
            {'label': 'Council', 'value': 'Council'},
            {'label': 'ZipCode', 'value': 'ZipCode'},
            {'label': 'FireComp', 'value': 'FireComp'},
            {'label': 'PolicePrct', 'value': 'PolicePrct'},
            {'label': 'Health Area', 'value': 'HealthArea'},
            {'label': 'SanitBoro', 'value': 'SanitBoro'},
            {'label': 'Address', 'value': 'Address'},
            {'label': 'BldgClass', 'value': 'BldgClass'},
            {'label': 'BsmtCode', 'value': 'BsmtCode'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},
        ], value=20,
                     clearable=True),
        html.Div(id='my-out41'),

    html.Div([dcc.Graph(id='box-graph41')
    ])

])
@my_app.callback(
            Output(component_id='my-out41', component_property='children'),
            [Input(component_id='my-drop41', component_property='value')])

def update_Stats(a1):
    A = df[a1]
    L = A.describe()
    return("Count: ", L[0],
                " Mean: ", L[1],
                   " Standard Deviation: ", L[2],
                   " Minimum: ", L[3],
                   " Median: ", L[5],
                   " Maximum: ", L[7])

@my_app.callback(
            Output(component_id='box-graph41', component_property='figure'),
            [Input(component_id='my-drop41', component_property='value')])

def update_box(a1):
    fig = px.box(df, y=a1)
    return(fig)

#=========================Fig1.5
fig1_5_layout=html.Div(
    [ html.P('Select a Column'),
        dcc.Dropdown(id='my-drop51', options=[
                     {'label': 'LotArea', 'value': 'LotArea'},
                     {'label': 'BldgArea', 'value': 'BldgArea'},
                     {'label': 'NumBldgs', 'value': 'NumBldgs'},
                     {'label': 'NumFloors', 'value': 'NumFloors'},
                    {'label': 'UnitsRes', 'value': 'UnitsRes'},
                     {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
                     {'label': 'LotFront', 'value': 'LotFront'},
                     {'label': 'LotDepth', 'value': 'LotDepth'},
                    {'label': 'BldgFront', 'value': 'BldgFront'},
                     {'label': 'BldgDepth', 'value': 'BldgDepth'},
                      {'label': 'BsmtCode', 'value': 'BsmtCode'},
                     {'label': 'AssessLand', 'value': 'AssessLand'},
                   {'label': 'AssessTot', 'value': 'AssessTot'},

                 ], clearable= True),
        html.Br(),
        html.P('Select a Margin Plot Type'),
dcc.Dropdown(id='my-marginal51', options=[
                      {'label': 'Box', 'value': 'box'},
                     {'label': 'Violin', 'value': 'violin'},
                   {'label': 'Rug', 'value': 'rug'},

                 ], clearable= True),
        html.Br(),
        dcc.Graph(id= 'my-graph51'),
        html.Br(),
        html.Div([

        ])
])

@my_app.callback(
            Output(component_id='my-graph51', component_property='figure'),
            [Input(component_id='my-drop51', component_property='value'),
             Input(component_id='my-marginal51', component_property='value')])

def update_Histo(B,C):
    fig151 = px.histogram(df, x=B, color=df['Borough'], marginal=C)
    fig151.update_layout(
        title="Borough Distribution Graph",
        xaxis_title=f"Column Values: {B}",
        yaxis_title="Frequency",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        )
    )
    return(fig151)

# #===========Fig1.6
fig1_6_layout= html.Div([
        html.P('Select a Column'),
    dcc.Slider(id='slider61', min=10, max=100, value=15,
               marks={10: '10',
                      25: '25',
                      40: '40',
                      65: '65',
                      80: '80',
                      95: '95',
                      100: '100'}),
        html.Br(),
        html.P('Select a Margin Plot Type'),
dcc.Dropdown(id='my-marginal61', options=[
                      {'label': 'Box', 'value': 'box'},
                     {'label': 'Violin', 'value': 'violin'},
                   {'label': 'Rug', 'value': 'rug'},

                 ], clearable= True),
        html.Br(),
        dcc.Graph(id= 'my-graph61'),
        html.Br(),
        html.Div([

        ])
])

@my_app.callback(
            Output(component_id='my-graph61', component_property='figure'),
            [Input(component_id='slider61', component_property='value'),
             Input(component_id='my-marginal61', component_property='value')])

def update_Histo(B,C):
    fig = px.histogram(df, x='AssessTot', color=df['Borough'], nbins=B, marginal=C)
    fig.update_layout(
        title="Borough Value Distribution Graph",
        xaxis_title=f"Total Value $USD",
        yaxis_title="Frequency",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        )
    )
    return(fig)
#=========Fig1.7
fig1_7_layout= html.Div([
 html.P('Select a Column'),
        dcc.Dropdown(id='my-drop71', options=[
                     {'label': 'LotArea', 'value': 'LotArea'},
                     {'label': 'BldgArea', 'value': 'BldgArea'},
                     {'label': 'NumBldgs', 'value': 'NumBldgs'},
                     {'label': 'NumFloors', 'value': 'NumFloors'},
                    {'label': 'UnitsRes', 'value': 'UnitsRes'},
                     {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
                     {'label': 'LotFront', 'value': 'LotFront'},
                     {'label': 'LotDepth', 'value': 'LotDepth'},
                    {'label': 'BldgFront', 'value': 'BldgFront'},
                     {'label': 'BldgDepth', 'value': 'BldgDepth'},
                      {'label': 'BsmtCode', 'value': 'BsmtCode'},
                     {'label': 'AssessLand', 'value': 'AssessLand'},
                   {'label': 'AssessTot', 'value': 'AssessTot'},

                 ], clearable= True),
        html.Br(),

        dcc.Dropdown(id='my-drop72', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea'},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'BsmtCode', 'value': 'BsmtCode'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},

        ], clearable=True),
        html.Br(),
        dcc.Graph(id= 'my-graph71'),
        html.Br(),
        html.Div([

        ])
])

@my_app.callback(
            Output(component_id='my-graph71', component_property='figure'),
            [Input(component_id='my-drop71', component_property='value'),
            Input(component_id='my-drop72', component_property='value')
             ])

def update_Bar(B, C):
    fig1 = px.bar(df, x=B, y=C, color=df['Borough'])
    fig1.update_layout(
        title="Borough Graph Bar Plot",
        xaxis_title=f"{B} Column Values",
        yaxis_title=f"{C} Column Values",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        )
    )
    return(fig1)

#============= Fig 1.8
fig1_8_layout = html.Div(
    [
        html.P('Select a Column'),
        dcc.Dropdown(id='my-drop81', options=[
                     {'label': 'SchoolDist', 'value': 'SchoolDist'},
                    {'label': 'FireComp', 'value': 'FireComp'},
                    {'label': 'PolicePrct', 'value': 'PolicePrct'},
                    {'label': 'HealthArea', 'value': 'HealthArea'},
                     {'label': 'SanitBoro', 'value': 'SanitBoro'},
                     {'label': 'NumBldgs', 'value': 'NumBldgs'},
                     {'label': 'NumFloors', 'value': 'NumFloors'},
                      {'label': 'BsmtCode', 'value': 'BsmtCode'},


                 ], clearable= True),
        html.Br(),

        html.Br(),
        dcc.Graph(id= 'my-graph81'),
        html.Br(),
        html.Div([

        ])
])

@my_app.callback(
            Output(component_id='my-graph81', component_property='figure'),
            [Input(component_id='my-drop81', component_property='value')
             ])

def update_Bar(B):
    fig1  = px.pie(df, values=B, names='Borough' ,title='Pie Chart by Borough')

    fig1.update_layout(
        title="Borough Pie Chart",
        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        )
    )
    return(fig1)
#=========Fig 1.9
fig1_9_layout = html.Div(
    [   html.H1('OLS Trend Scatter Plot'),
        html.P('Desired Predictor For Scatter Plot'),
        dcc.RadioItems(id='myRad91', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea'},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},
        ], inline=True),
        html.Br(),
html.P('Desired Target For Scatter Plot'),
    dcc.RadioItems(id='myRad92', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea'},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},
        ], inline=True),

    html.Div([dcc.Graph(id='mygraph91')
    ])

])
@my_app.callback(
            Output(component_id='mygraph91', component_property='figure'),
            [Input(component_id='myRad91', component_property='value'),
             Input(component_id='myRad92', component_property='value')])

def update_OLS(a1, b1):
    fig = px.scatter(df, x=a1, y=b1, color='Borough', trendline="ols",
                     trendline_scope="overall")
    fig.update_layout(
        title="OLS Scatter",
        xaxis_title=f"Predictor Variable: {a1}",
        yaxis_title=f"Target Variable: {b1}",

        font=dict(
            family="Courier New, monospace",
            size=18,
            color="RebeccaPurple"
        ))
    return fig
#============================Fig1.10

fig1_10_layout = html.Div(
    [

        html.P('Select a Column'),
dcc.Dropdown(id='my-drop101', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea'},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'BsmtCode', 'value': 'BsmtCode'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},
#
        ], clearable=True)
        ,
        html.Br(),
        html.Div([dcc.Graph(id='mygraph101')

])
    ])

@my_app.callback(
            Output(component_id='mygraph101', component_property='figure'),
            Input(component_id='my-drop101', component_property='value'),
             )

def update_Histo(B):
    dfQN=df[df['Borough']=='QN']
    dfMN = df[df['Borough'] == 'MN']
    dfBK = df[df['Borough'] == 'BK']
    dfBX = df[df['Borough'] == 'BX']
    dfSI = df[df['Borough'] == 'SI']
    GL=['QN','MN','BK','BX','SI']
    data=[dfQN[B],dfMN[B],dfBK[B],dfBX[B],dfSI[B],]

    fig1 = ff.create_distplot(data, GL)
    # fig1.update_layout(
    #         title="Borough Histogram KDE Plot",
    #         xaxistitle= 'Probability Density',
    #         yaxistitle=f'Column Value: {B}',
    #         font=dict(
    #             family="Courier New, monospace",
    #             size=18,
    #             color="RebeccaPurple",
    #
    #         )
    #     )
    return(fig1)
#======================================Fig1.11
fig1_11_layout = html.Div(
    [   html.H1('Numerical-Categorical Subplots'),
        html.P('Desired Numerical Column'),
        dcc.Dropdown(id='mydrop111', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea'},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'BsmtCode', 'value': 'BsmtCode'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},
#
        ], clearable=True),
dcc.Dropdown(id='mydrop112', options=[
            {'label': 'LotArea', 'value': 'LotArea'},
            {'label': 'BldgArea', 'value': 'BldgArea'},
            {'label': 'NumBldgs', 'value': 'NumBldgs'},
            {'label': 'NumFloors', 'value': 'NumFloors'},
            {'label': 'UnitsRes', 'value': 'UnitsRes'},
            {'label': 'UnitsTotal', 'value': 'UnitsTotal'},
            {'label': 'LotFront', 'value': 'LotFront'},
            {'label': 'LotDepth', 'value': 'LotDepth'},
            {'label': 'BldgFront', 'value': 'BldgFront'},
            {'label': 'BldgDepth', 'value': 'BldgDepth'},
            {'label': 'BsmtCode', 'value': 'BsmtCode'},
            {'label': 'AssessLand', 'value': 'AssessLand'},
            {'label': 'AssessTot', 'value': 'AssessTot'},
#
        ], clearable=True),

        html.P('SubSample Size'),
        dcc.Input(
            id="Sample Size111",
            type="number",
            placeholder="Samples"),
        html.P('SubSample Seed'),
        dcc.Input(
            id="Seed111",
            type="number",
            placeholder="Seed"),

        html.Div([dcc.Graph(id='mygraph111')
    ])

])
@my_app.callback(
            Output(component_id='mygraph111', component_property='figure'),
            [Input(component_id='mydrop111', component_property='value'),
            Input(component_id='mydrop112', component_property='value'),
             Input(component_id='Sample Size111', component_property='value'),
             Input(component_id='Seed111', component_property='value')])


def update_Subplot(a1, b1, c, d):
    DF=df.sample(n=c, random_state=d)
    x=df[a1].values
    y=df[b1].values
    fig = make_subplots(rows=1, cols=3,
                        column_widths=[0.4, 0.4, 0.4],
                        subplot_titles=(f'Scatter of Columns {a1} and {b1}',
                                        f'Selected Column: {a1}',
                                        f'Selected Column: {b1}'))
    for i in range(0, 3):
        R=0
        C=0
        if i == 0:
            R = 1
            C = 1
            fig.add_trace(go.Scatter(x=x, y=y, mode='markers'),
                          row=R, col=C)
        elif i == 1:
            R = 1
            C = 2
            fig.add_trace(go.Histogram(x=x, nbinsx=50),
                          row=R, col=C)

        elif i == 2:
            R = 1
            C = 3
            fig.add_trace(go.Histogram(x=y, nbinsx=50),
                          row=R, col=C)

    return (fig)
#===========================Fig1.12
fig1_12_layout = html.Div( [
        html.H1('Download Dataset as .csv'),
        html.Button("Download Data", id="btn_csv"),
        dcc.Download(id="download-df"),
    ]
)
@my_app.callback(
    Output("download-df", "data"),
    Input("btn_csv", "n_clicks"),
    prevent_initial_call=True,
)
def func(n_clicks):
    return dcc.send_data_frame(df.to_csv, "df")
#================Tab Call
@my_app.callback(Output(component_id='layout', component_property='children'),
                 [Input(component_id='hw-questions', component_property='value')])

def update_layout(Q):
    if Q == 'f01':
        return fig0_1_layout
    if Q == 'f02':
        return fig0_2_layout
    if Q == 'f11':
        return fig1_1_layout
    if Q == 'f12':
        return fig1_2_layout
    if Q == 'f13':
        return fig1_3_layout
    if Q == 'f14':
        return fig1_4_layout
    if Q == 'f15':
        return fig1_5_layout
    if Q == 'f16':
        return fig1_6_layout
    if Q == 'f17':
        return fig1_7_layout
    if Q == 'f18':
        return fig1_8_layout
    if Q == 'f19':
        return fig1_9_layout
    if Q == 'f110':
        return fig1_10_layout
    if Q == 'f111':
        return fig1_11_layout
    if Q == 'f112':
        return fig1_12_layout

my_app.server.run(debug=True)